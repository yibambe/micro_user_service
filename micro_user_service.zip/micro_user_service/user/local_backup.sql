--
-- PostgreSQL database dump
--

\restrict 1scdktcB2TnSJOdTHp7sP7kOnnki0UBdty0NjWTvDMEkGGVLSwrm1yeBzo8ZKRw

-- Dumped from database version 18.2 (Debian 18.2-1.pgdg13+1)
-- Dumped by pg_dump version 18.2 (Debian 18.2-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: increment_version(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.increment_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN

    NEW."version" = OLD."version" + 1;

    RETURN NEW;

END;

$$;


ALTER FUNCTION public.increment_version() OWNER TO admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN

    NEW.updated_at = NOW();

    RETURN NEW;

END;

$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    email character varying(100) NOT NULL,
    role character varying(30) NOT NULL,
    store_id uuid NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    attributes jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(100),
    updated_by character varying(100),
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'locked'::character varying, 'deleted'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO admin;

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users (id, username, password_hash, email, role, store_id, status, attributes, created_at, updated_at, created_by, updated_by, version) FROM stdin;
2d0d66a2-fb77-4c1d-80be-aaa899a15666	gerente_maria	$2a$10$XQ1L5k5k5k5k5k5k5k5k5u5k5k5k5k5k5k5k5k5k5k5k5k5k5k5	maria.garcia@tienda1.com	gerente	b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22	active	{"department": "ventas"}	2026-02-14 22:55:44.399246+00	2026-02-14 22:55:44.399246+00	system	system	1
1993d1e7-6caa-4d15-9d63-482cfe45ad3b	supervisor_carlos	$2a$10$XQ1L5k5k5k5k5k5k5k5k5u5k5k5k5k5k5k5k5k5k5k5k5k5k5k5	carlos.lopez@tienda1.com	supervisor	b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22	active	{"shift": "morning"}	2026-02-14 22:55:44.399246+00	2026-02-14 22:55:44.399246+00	system	system	1
7a328672-86d0-4a11-8458-517c09fa1e2c	cajero_ana	$2a$10$XQ1L5k5k5k5k5k5k5k5k5u5k5k5k5k5k5k5k5k5k5k5k5k5k5k5	ana.martinez@tienda1.com	cajero	b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22	active	{"terminal": 1}	2026-02-14 22:55:44.399246+00	2026-02-14 22:55:44.399246+00	system	system	1
9c4d21c5-ada1-48af-89de-3ec18df8bc85	cajero_luis	$2a$10$XQ1L5k5k5k5k5k5k5k5k5u5k5k5k5k5k5k5k5k5k5k5k5k5k5k5	luis.rodriguez@tienda1.com	cajero	b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22	active	{"terminal": 2}	2026-02-14 22:55:44.399246+00	2026-02-14 22:55:44.399246+00	system	system	1
c6ab059c-fec3-408e-ab31-b5e2189232f3	gerente_sofia	$2a$10$XQ1L5k5k5k5k5k5k5k5k5u5k5k5k5k5k5k5k5k5k5k5k5k5k5k5	sofia.ramirez@tienda2.com	gerente	c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	active	{}	2026-02-14 22:55:44.399246+00	2026-02-14 22:55:44.399246+00	system	system	1
e8116aef-1d92-40a6-b4bf-5b06855191e5	supervisor_diego	$2a$10$XQ1L5k5k5k5k5k5k5k5k5u5k5k5k5k5k5k5k5k5k5k5k5k5k5k5	diego.fernandez@tienda2.com	supervisor	c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	active	{"shift": "afternoon"}	2026-02-14 22:55:44.399246+00	2026-02-14 22:55:44.399246+00	system	system	1
ed5c82dc-6f17-4a2b-89cd-394785c51cbf	cajero_elena	$2a$10$XQ1L5k5k5k5k5k5k5k5k5u5k5k5k5k5k5k5k5k5k5k5k5k5k5k5	elena.torres@tienda2.com	cajero	c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	active	{"terminal": 3}	2026-02-14 22:55:44.399246+00	2026-02-14 22:55:44.399246+00	system	system	1
df877415-2014-4245-8394-41836e68410b	cajero_pablo	$2a$10$XQ1L5k5k5k5k5k5k5k5k5u5k5k5k5k5k5k5k5k5k5k5k5k5k5k5	pablo.gomez@tienda2.com	cajero	c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	inactive	\N	2026-02-14 22:55:44.399246+00	2026-02-14 22:55:44.399246+00	system	system	1
1590b512-266f-4052-b633-64a297e643b0	admin_roberto	$2a$10$XQ1L5k5k5k5k5k5k5k5k5u5k5k5k5k5k5k5k5k5k5k5k5k5k5k5	roberto.diaz@empresa.com	administrador	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	active	{"role_level": 1}	2026-02-14 22:55:44.399246+00	2026-02-14 22:55:44.399246+00	system	system	1
b9c7c3b9-197e-4120-af68-3cde505c17ad	admin_juan	123	juan.perez@empresa.com	administrador	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	active	{"theme": "dark", "language": "es"}	2026-02-14 22:55:44.399246+00	2026-02-14 23:00:37.185665+00	system	system	2
\.


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_users_attributes; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_users_attributes ON public.users USING gin (attributes);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- Name: idx_users_store_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_users_store_id ON public.users USING btree (store_id);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: users trigger_increment_users_version; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trigger_increment_users_version BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.increment_version();


--
-- Name: users trigger_update_users_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trigger_update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- PostgreSQL database dump complete
--

\unrestrict 1scdktcB2TnSJOdTHp7sP7kOnnki0UBdty0NjWTvDMEkGGVLSwrm1yeBzo8ZKRw

