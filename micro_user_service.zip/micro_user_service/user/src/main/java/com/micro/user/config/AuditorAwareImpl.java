package com.micro.user.config;

import java.util.Optional;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // Aquí se debería obtener el usuario autenticado desde el contexto de seguridad.
        // Por simplicidad, retornamos "system" o podrías obtenerlo de SecurityContextHolder.
        // En un entorno real, implementarías algo como:
        // Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        // if (auth != null) return Optional.of(auth.getName());
        return Optional.of("system");
    }
}
