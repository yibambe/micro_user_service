package com.micro.user.dto;

import java.util.Map;
import java.util.UUID;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record UserRequest(
        @NotBlank(message = "Username is required") @Size(max = 50,
                message = "Username must be less than 50 characters") String username,

        @NotBlank(message = "Password is required") @Size(min = 6, max = 100,
                message = "Password must be between 6 and 100 characters") String password,

        @NotBlank(message = "Email is required") @Email(message = "Email should be valid") @Size(
                max = 100, message = "Email must be less than 100 characters") String email,

        @NotBlank(message = "Role is required") @Size(max = 30,
                message = "Role must be less than 30 characters") String role,

        @NotNull(message = "Store ID is required") UUID storeId,

        @Size(max = 20, message = "Status must be less than 20 characters") String status, // opcional,
                                                                                           // por
                                                                                           // defecto
                                                                                           // 'active'
                                                                                           // en la
                                                                                           // BD

        Map<String, Object> attributes) {
}
