package com.micro.user.dto;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

public record UserResponse(UUID id, String username, String email, String role, UUID storeId,
        String status, Map<String, Object> attributes, OffsetDateTime createdAt,
        OffsetDateTime updatedAt, String createdBy, String updatedBy, Integer version) {
}
