package com.micro.user.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.micro.user.dto.UserRequest;
import com.micro.user.dto.UserResponse;
import com.micro.user.entity.UserEntity;
import com.micro.user.exception.DuplicateResourceException;
import com.micro.user.exception.ResourceNotFoundException;
import com.micro.user.mapper.UserMapper;
import com.micro.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;

    @Transactional(readOnly = true)
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream().map(userMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public UserResponse getUserById(UUID id) {
        UserEntity user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        return userMapper.toResponse(user);
    }

    @Transactional
    public UserResponse createUser(UserRequest request) {
        // Validar unicidad de username y email
        if (userRepository.existsByUsername(request.username())) {
            throw new DuplicateResourceException("Username already exists: " + request.username());
        }
        if (userRepository.existsByEmail(request.email())) {
            throw new DuplicateResourceException("Email already exists: " + request.email());
        }

        UserEntity user = userMapper.toEntity(request);
        // Encriptar contraseña
        user.setPasswordHash(passwordEncoder.encode(request.password()));
        // Si no se envía status, la BD pondrá 'active' por defecto
        if (request.status() != null) {
            user.setStatus(request.status());
        }

        UserEntity savedUser = userRepository.save(user);
        log.info("User created: {}", savedUser.getUsername());
        return userMapper.toResponse(savedUser);
    }

    @Transactional
    public UserResponse updateUser(UUID id, UserRequest request) {
        UserEntity existingUser = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));

        // Verificar unicidad si username o email cambian
        if (!existingUser.getUsername().equals(request.username())
                && userRepository.existsByUsername(request.username())) {
            throw new DuplicateResourceException("Username already exists: " + request.username());
        }
        if (!existingUser.getEmail().equals(request.email())
                && userRepository.existsByEmail(request.email())) {
            throw new DuplicateResourceException("Email already exists: " + request.email());
        }

        // Actualizar campos
        userMapper.updateEntityFromRequest(request, existingUser);
        // Si se envía nueva contraseña, actualizarla
        if (request.password() != null && !request.password().isBlank()) {
            existingUser.setPasswordHash(passwordEncoder.encode(request.password()));
        }
        // Actualizar status si viene
        if (request.status() != null) {
            existingUser.setStatus(request.status());
        }

        UserEntity updatedUser = userRepository.save(existingUser);
        log.info("User updated: {}", updatedUser.getUsername());
        return userMapper.toResponse(updatedUser);
    }

    @Transactional
    public void deleteUser(UUID id) {
        UserEntity user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        // Soft delete: cambiar status a 'deleted'
        user.setStatus("deleted");
        userRepository.save(user);
        log.info("User soft deleted: {}", user.getUsername());
    }

    @Transactional
    public UserResponse updateUserStatus(UUID id, String status) {
        UserEntity user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        user.setStatus(status);
        UserEntity updated = userRepository.save(user);
        log.info("User status updated: {} -> {}", user.getUsername(), status);
        return userMapper.toResponse(updated);
    }
}
