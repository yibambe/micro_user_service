package com.micro.user.Test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserApplicationTests {

    @Test
    void contextLoads() {}

}
// sk-user-G-Ncj29UWrLij3Xd438DV194sjm5UObx5uglfkCtUpk-SUqSgv9lSiM5Fv3O3qbW6v5LtUzLp4Z0ZnhmirKvXMYReCvY6od67LNrQ-x0rkmzhbFyH-kNNSZ3lk7Oujp9KGg
